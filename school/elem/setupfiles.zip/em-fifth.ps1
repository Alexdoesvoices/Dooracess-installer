$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location -Path $ScriptDir
if (Test-Path ".\.env.ps1") { . ".\.env.ps1" }

try {
    $code = @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(ServicePoint s, X509Certificate c, WebRequest r, int p) { return true; }
    }
"@
    Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue
} catch {}

[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$doorId = "8869c473-4a11-47de-aa53-697bb16f0820"

Write-Host "Unlocking Fifth Door..." -ForegroundColor Cyan
try {
    Invoke-RestMethod -Method PUT -Uri "https://10.52.50.2:12445/api/v1/developer/doors/$doorId/unlock" `
    -TimeoutSec 5 -Headers @{ Authorization = "Bearer $APIKEY"; "Content-Type" = "application/json" } -Body "{}"
    Write-Host "SUCCESS!" -ForegroundColor Green
    Start-Sleep -Seconds 1
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    pause
}