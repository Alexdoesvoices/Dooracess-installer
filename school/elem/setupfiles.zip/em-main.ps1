# 1. Bypass SSL/Certificate warnings for the local door server
try {
    $code = @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(ServicePoint s, X509Certificate c, WebRequest r, int p) { return true; }
    }
"@
    Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue
} catch {}

[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# 2. Load the API Key from the same folder
# The space after the first dot is required to "import" the variables
if (Test-Path ".\.env.ps1") {
    . ".\.env.ps1"
} else {
    Write-Host "Error: .env.ps1 not found in this folder." -ForegroundColor Red
    exit
}

# 3. Setup variables (Pulling $APIKEY from the .env.ps1 file)
$token  = $APIKEY
$doorId = "3e3b35ab-4a3f-436e-b45c-4fac5589aafd"
$url    = "https://10.52.50.2:12445/api/v1/developer/doors/$doorId/unlock"

# 4. Validate token exists
if (-not $token) {
    Write-Host "Error: API Key is blank. Run setup first." -ForegroundColor Red
    exit
}

# 5. Execute the Unlock Request
Write-Host "Sending unlock command to Door $doorId..." -ForegroundColor Cyan

try {
    Invoke-RestMethod `
        -Method PUT `
        -Uri $url `
        -TimeoutSec 5 `
        -Headers @{
            Authorization  = "Bearer $token"
            "Content-Type" = "application/json"
            Accept         = "application/json"
        } `
        -Body "{}"
    
    Write-Host "SUCCESS: Door unlocked." -ForegroundColor Green
} 
catch {
    Write-Host "FAILURE: Could not reach door controller." -ForegroundColor Red
    Write-Host "Details: $($_.Exception.Message)" -ForegroundColor Gray
}