# 1. Define the path
$envPath = Join-Path -Path $PSScriptRoot -ChildPath "/.env.ps1"

# 2. Load it the PowerShell way (Dot-Sourcing)
if (Test-Path $envPath) {
    . $envPath   # <--- The dot followed by a SPACE is the magic part
    Write-Host "Success: Variables loaded from .env.ps1" -ForegroundColor Green
} else {
    Write-Host "Error: .env.ps1 file not found at $envPath" -ForegroundColor Red
}

# 3. Use it
$token = $APIKEY
Write-Host "Your token is: $token"